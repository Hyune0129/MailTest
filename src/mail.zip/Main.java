
public class Main {
	public static void main(String args[]) {
		String host = "smtp.naver.com";
		final String username = "project_boardcar";
		final String password = "yuse2022";
		int port = 465;
		String receiver = "hyune0129@naver.com";
		String title = "Hi";
		String body = "This is test!";
		MailSend ms = new MailSend();
		ms.send(host, port, username, password, receiver, title, body);
		System.out.println("송신완료");
	}
}
